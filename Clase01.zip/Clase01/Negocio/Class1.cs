﻿using System;

namespace Negocio
{
    public class Class1
    {

    }
}
