﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Negocio.Modelo
{
    /// <summary>
    /// la capa de modelo se encarga de llamar realizar los calculos de la logica.
    /// por ejemplo
    /// </summary>
    class Usuario
    {
    }
}
